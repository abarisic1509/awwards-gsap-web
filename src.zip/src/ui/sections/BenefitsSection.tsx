import React from "react";

const BenefitsSection: React.FC = () => {
  return <div className="min-h-screen">BenefitsSection</div>;
};

export default BenefitsSection;
