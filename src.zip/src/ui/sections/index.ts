export { default as HeroSection } from "./HeroSection";
export { default as MessageSection } from "./MessageSection";
export { default as FlavorsSection } from "./FlavorsSection";
export { default as NutritionSection } from "./NutritionSection";
export { default as BenefitsSection } from "./BenefitsSection";
