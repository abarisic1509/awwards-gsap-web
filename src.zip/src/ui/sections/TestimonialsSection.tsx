import React from "react";

const TestimonialsSection: React.FC = () => {
  return <div className="min-h-screen">TestimonialsSection</div>;
};

export default TestimonialsSection;
