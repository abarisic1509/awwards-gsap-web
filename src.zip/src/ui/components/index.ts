export { default as NavBar } from "./NavBar";
export { default as Footer } from "./Footer";
